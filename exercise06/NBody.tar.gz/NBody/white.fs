#version 140

out vec4 outColor;

void main(void)
{
     outColor = vec4(1.0, 1.0, 1.0, 1.0);
}
